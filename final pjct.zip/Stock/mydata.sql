
select * from HQ_ADMIN;

create table HQ_ADMIN(username varchar2(40), pass varchar2(48));
insert into hq_loginn values('admin','admin@gmail.com','admin');

create table HQ_loginn(name varchar2(30) not null, email varchar2(40) not null, password varchar2(30) not null, desig varchar2(30) not null);

select * from HQ_loginn;

delete from hq_loginn;


drop table HQ_loginn;
insert into hq_loginn values('admin','admin@gmail.com','admin','admin');
create table item(Id varchar2(30), Type varchar2(30), Description varchar2(30), Price varchar2(30), discount varchar2(30), quantity number(10), category varchar2(30));

create table HQ_item(Id varchar2(30), Type varchar2(30), Description varchar2(30), Price varchar2(30), discount varchar2(30), quantity number(10), category varchar2(30));
select * from HQ_itemlist order by I_ID;
alter table hq_itemlist drop CONSTRAINT i_id;
create table HQ_itemlist(i_id number(10), i_name varchar2(50), i_desc varchar2(50), i_quantity varchar2(10), i_costprice number(10), i_sellingprice number(10));
insert into HQ_itemlist values(1,'stock_1','brand_1',10,30,40);
insert into HQ_itemlist values(2,'stock_2','brand_5',30,70,80);
insert into HQ_itemlist values(3,'stock_3','brand_3',8,20,30);
insert into HQ_itemlist values(4,'stock_4','brand_2',40,15,20);
insert into HQ_itemlist values(5,'stock_5','brand_1',90,30,40);
insert into HQ_itemlist values(6,'stock_6','brand_7',26,12,40);
insert into HQ_itemlist values(7,'stock_7','brand_4',33,60,80);
insert into HQ_itemlist values(8,'stock_8','brand_2',17,30,40);
insert into HQ_itemlist values(9,'stock_9','brand_2',2,20,45);
insert into HQ_itemlist values(10,'stock_10','brand_3',11,50,60);

drop table hq_itemlist;

UPDATE HQ_itemlist SET I_NAME=?,I_DESC=?,I_QUANTITY=?, I_COSTPRICE=?, I_SELLINGPRICE=? WHERE I_ID=?



UPDATE HQ_itemlist SET I_NAME=?,I_DESC=?,I_QUANTITY=?, I_COSTPRICE, I_SELLINGPRICE WHERE I_ID=?;


 select a.i_id, a.i_name, a.i_desc, b.quantity, (a.i_sellingprice)*(b.quantity) Cost from hq_itemlist a join hq_add b on a.i_id=b.id order by b.id;

create table hq_daily(id number(10) primary key, stock varchar2(30) not null, brand varchar2(30) not null, qty number(10) not null);

select * from HQ_daily;

select * from HQ_itemlist;
create table hq_add(id number(10), quantity number(10));

select * from HQ_add; 9 varnum 
select id,name,description,sum(quantity),sum(cost) from hq_dailysoldoutt group by id,name,description order by id;

select sum(quantity),id from hq_add group by id;

https://raw.githubusercontent.com/khadkamhn/day-01-login-form/master/img/bg
select a.i_id, a.i_name, a.i_desc, sum(b.quantity), (a.i_sellingprice)*(b.quantity) Cost from hq_itemlist a join hq_add b on a.i_id=b.id group by b.id,b.quantity order by b.id
select sum((a.i_sellingprice)*(b.quantity)) totalCost from hq_itemlist a join hq_add b on a.i_id=b.id group by b.id order by b.id;


create table hq_dailysoldoutt(id number(10), name varchar2(30), description varchar2(30), quantity number(10), cost number(10));

select i_id,i_name,i_desc,quantity,cost from hq_addd ;
select * from hq_dailysoldoutt;
select id,name,desc,sum(quantity),sum(cost) from hq_dailysoldoutt group by id,name,desc order by id;

select i_id,i_name,i_desc,count(quantity) from hq_dailycost group by i_id;

select i_id,i_name,i_desc,sum(quantity),sum(cost) from hq_dailycost group by i_id,i_name,i_desc order by i_id;

select i_id,sum(quantity) from hq_dailycost group by i_id;
select * from hq_add;
delete from hq_dailysoldoutt;
delete from hq_add;
select id,quantity from hq_add group by id;
insert into hq_dailysoldoutt(id,name,description,quantity,cost) select a.i_id, a.i_name, a.i_desc, b.quantity, (a.i_sellingprice)*(b.quantity) Cost from hq_itemlist a join hq_add b on a.i_id=b.id order by b.id;

drop table hq_order;
create table hq_order(order_id number(10), order_name varchar2(30), order_desc varchar2(30), order_qty number(10));
delete from hq_order;
select * from hq_order;
select i_id,i_name,i_desc from hq_itemlist where i_quantity<10 order by i_id;;
insert into hq_order values(4,'stock','brand',1);
insert into hq_order values(4,'stock','brand',2);

select order_id,order_name,order_desc, sum(order_qty) from hq_order group by order_id,order_name,order_desc

