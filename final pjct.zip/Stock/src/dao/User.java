package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import util.DbConnection;

public class User {
                
                public User() {
                                super();
                }
                public void methoduser(String nam,String email,String pass,String des){
                                int flag=0;
        PreparedStatement stmt=null;
        String str="";
        DbConnection db=new DbConnection();
        Connection con= DbConnection.getDBConn();
                                try {

           stmt = con.prepareStatement("insert into HQ_loginn values(?,?,?,?)");
              stmt.setString(1,nam);
              stmt.setString(2, email);
               stmt.setString(3, pass);   
               stmt.setString(4, des); 
               
              stmt.executeUpdate();
                    
              } catch (SQLException e2) {
                     System.out.println("Error occured!");
                     e2.printStackTrace();
              }
              finally{
                     try {
                            if(stmt != null)                                
                            stmt.close();                     
                            con.commit();
                            if(con != null)
                            con.close();
                     }                    
                     catch (SQLException e) {
                                   e.printStackTrace();
                            }
              }


                }

}
